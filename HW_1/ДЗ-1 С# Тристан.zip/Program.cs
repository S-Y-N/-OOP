﻿using System;


namespace HomeWork1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ты жив, здоров, беспечен, пей пока\n");
            Console.Write("С красавицей, как роза цветника,\n");
            Console.Write("Покамест не сорвет дыханье смерти\n");
            Console.Write("Твой краткий век подобьем лепестка.\n");
            Console.Write("\n\t\t\tОмар Хаям\n");
        }
    }
}



