﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StreetRacer
{
    enum GameObjectType
    {
        Buggati =1,//cars
        BMW=2,
        Sprinter=3,
        Belaz=4,
        Finish=5//финишная линия

    }
}
