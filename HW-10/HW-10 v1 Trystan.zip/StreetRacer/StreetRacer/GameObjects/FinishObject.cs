﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StreetRacer
{
    class FinishObject : CarObject
    {
    }
}
