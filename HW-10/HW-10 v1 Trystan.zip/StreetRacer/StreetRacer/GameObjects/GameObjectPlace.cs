﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StreetRacer
{
    class GameObjectPlace
    {
        //получаем инкапсулированую логику какой-то точки
        public int XCoordinate { get; set; }
        public int YCoordinate { get; set; }
    }
}
